package com.chen.jpareferquery.entity;

public enum Gender {
    MALE,
    FEMALE
}
