package com.chen.jpareferquery.controller;

import com.alibaba.fastjson.JSONObject;
import com.chen.jpareferquery.dto.WechatAccessTokenDto;
import com.chen.jpareferquery.dto.WechatUserInfoDto;
import com.chen.jpareferquery.utils.HttpClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {


    private static String appID = "wx4a23b8d086567628";
    private static String appsecret = "f0264832c59c253f020c3463125e4f76";

    /**
     * https://open.weixin.qq.com/connect/oauth2/authorize?
     * appid=APPID
     * &redirect_uri=REDIRECT_URI
     * &response_type=code
     * &scope=SCOPE
     * &state=STATE#wechat_redirect
     */

    @GetMapping("/test")
    public void test() {

        String redirect_uri_first = "http%3a%2f%2fs3qci3.natappfree.cc%2fhello";

        String url_first = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + appID
                + "&redirect_uri=" + redirect_uri_first + "&response_type=code"
                + "&scope=snsapi_base" + "&state=STATE#wechat_redirect";

        System.out.println(url_first);
        HttpClient.getJSONObjectByGet(url_first);


    }

    @GetMapping("/hello")
    public WechatUserInfoDto hello(String code, String state) {
        //换取 access_token
        /**
         *
         https://api.weixin.qq.com/sns/oauth2/access_token?
         appid=APPID
         &secret=SECRET
         &code=CODE
         &grant_type=authorization_code
         */
        String url_access_token = getString("https://api.weixin.qq.com/sns/oauth2/access_token?", "appid=", appID, "&secret=", appsecret, "&code=", code, "&grant_type=authorization_code");

        JSONObject jsonObjectByGet = HttpClient.getJSONObjectByGet(url_access_token);
        String access_token = (String) jsonObjectByGet.get("access_token");
        Integer expires_in = (Integer) jsonObjectByGet.get("expires_in");
        String refresh_token = (String) jsonObjectByGet.get("refresh_token");
        String openid = (String) jsonObjectByGet.get("openid");
        String scope = (String) jsonObjectByGet.get("scope");


        WechatAccessTokenDto wechatAccessTokenDto = new WechatAccessTokenDto();
        wechatAccessTokenDto.setAccess_token(access_token);
        wechatAccessTokenDto.setExpires_in(expires_in);
        wechatAccessTokenDto.setOpenid(openid);
        wechatAccessTokenDto.setRefresh_token(refresh_token);
        wechatAccessTokenDto.setScope(scope);
        System.out.println(wechatAccessTokenDto);

        /**
         *
         第四步：拉取用户信息(需scope为 snsapi_userinfo)
         https://api.weixin.qq.com/sns/userinfo?
         access_token=ACCESS_TOKEN
         &openid=OPENID
         &lang=zh_CN
         */

        String string = getString("https://api.weixin.qq.com/sns/userinfo?" +
                "access_token=", access_token + "&openid=", openid, "&lang=zh_CN");
        JSONObject userInfo = HttpClient.getJSONObjectByGet(string);
        String openid1 = (String) userInfo.get("openid");
        String nickname = (String) userInfo.get("nickname");
        Integer sex = (Integer) userInfo.get("sex");
        String province = (String) userInfo.get("province");
        String city = (String) userInfo.get("city");
        String country = (String) userInfo.get("country");
        String headimgurl = (String) userInfo.get("headimgurl");
//        String[] privilege = (String[]) userInfo.get("privilege");
        String unionid = (String) userInfo.get("unionid");


        WechatUserInfoDto wechatUserInfoDto = new WechatUserInfoDto();
        wechatUserInfoDto.setOpenid(openid1);
        wechatUserInfoDto.setNickname(nickname);
        wechatUserInfoDto.setSex(sex);
        wechatUserInfoDto.setProvince(province);
        wechatUserInfoDto.setCity(city);
        wechatUserInfoDto.setCountry(country);
        wechatUserInfoDto.setHeadimgurl(headimgurl);
//        wechatUserInfoDto.setPrivilege(privilege);
        wechatUserInfoDto.setUnionid(unionid);

        return wechatUserInfoDto;
    }


    private String getString(String... d) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String s : d) {
            stringBuilder.append(s);
        }
        return stringBuilder.toString();
    }

}
