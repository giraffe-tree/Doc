package com.chen.jpareferquery.service;

import com.chen.jpareferquery.dao.PostRepository;
import com.chen.jpareferquery.entity.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.*;


@Service
public class PostServiceImpl {

    @Autowired
    PostRepository postRepository;


    public void post() {
        Specification<Post> specification = new Specification<Post>() {
            @Override
            public Predicate toPredicate(Root<Post> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                CriteriaUpdate<Post> update = cb.createCriteriaUpdate(Post.class);
                Root<Post> root1 = update.from(Post.class);
                update.set("",1);

                return null;
            }
        };

    }


}
