package com.chen.jpareferquery.test;

import com.chen.jpareferquery.utils.HttpClient;
import org.springframework.web.bind.annotation.GetMapping;

public class Test {

    private static String appID = "wx4a23b8d086567628";
    private static String appsecret = "f0264832c59c253f020c3463125e4f76";


    public static void main(String[] args) {
        test();
    }
    /**
     *
     *
     https://open.weixin.qq.com/connect/oauth2/authorize?
     appid=APPID
     &redirect_uri=REDIRECT_URI
     &response_type=code
     &scope=SCOPE
     &state=STATE#wechat_redirect

     */

    public static void test() {

        String redirect_uri_first = "http%3a%2f%2fs3qci3.natappfree.cc%2fhello";

        String url_first = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + appID
                + "&redirect_uri=" + redirect_uri_first + "&response_type=code"
                + "&scope=snsapi_base" + "&state=STATE#wechat_redirect";

        System.out.println(url_first);
//        HttpClient.getJSONObjectByGet(url_first);


    }
}
