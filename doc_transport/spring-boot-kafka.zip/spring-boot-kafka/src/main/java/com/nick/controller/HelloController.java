package com.nick.controller;

import com.nick.basic.Basic;
import com.nick.basic.BasicProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @Autowired
    private BasicProducer basicProducer;

    @GetMapping("/hello")
    public void hello(
            @RequestParam(value = "topic", required = false, defaultValue = "hello") String topic,
            @RequestParam(value = "content", required = false, defaultValue = "content") String content,
            @RequestParam(value = "id", required = false, defaultValue = "1") String id
    ) {
        basicProducer.send(topic, new Basic(id, content));

    }

}
